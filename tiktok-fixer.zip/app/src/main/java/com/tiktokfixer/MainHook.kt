package com.tiktokfixer

import android.app.Application
import android.content.ComponentCallbacks2
import android.content.res.Configuration
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != "com.zhiliaoapp.musically") return

        XposedHelpers.findAndHookMethod(
            Application::class.java,
            "onCreate",
            object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    val app = param.thisObject as Application
                    XposedBridge.log("[TikTokFixer] Attached to TikTok")

                    // Register memory trim callbacks — TikTok ignores these by default
                    app.registerComponentCallbacks(object : ComponentCallbacks2 {
                        override fun onConfigurationChanged(newConfig: Configuration) {}

                        override fun onLowMemory() {
                            XposedBridge.log("[TikTokFixer] onLowMemory — forcing GC")
                            System.gc()
                            System.runFinalization()
                            System.gc()
                        }

                        override fun onTrimMemory(level: Int) {
                            if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
                                XposedBridge.log("[TikTokFixer] onTrimMemory level=$level — forcing GC")
                                System.gc()
                                System.runFinalization()
                                System.gc()
                            }
                        }
                    })

                    // Watchdog thread: nudge GC when heap usage exceeds 75%
                    // Prevents the OOM cascade seen in logcat where 50+ threads
                    // block on "Waiting for a blocking GC Alloc"
                    Thread {
                        while (true) {
                            try {
                                Thread.sleep(8000)
                                val rt = Runtime.getRuntime()
                                val used = rt.totalMemory() - rt.freeMemory()
                                val max = rt.maxMemory()
                                if (used.toFloat() / max.toFloat() > 0.75f) {
                                    XposedBridge.log("[TikTokFixer] Heap ${used / 1048576}MB/${max / 1048576}MB — nudging GC")
                                    System.gc()
                                }
                            } catch (_: InterruptedException) {
                                break
                            }
                        }
                    }.apply {
                        isDaemon = true
                        name = "tiktokfixer-watchdog"
                        start()
                    }
                }
            }
        )
    }
}
