package com.nono.tiktokfixer.hooks;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class GCHook {

    private static final long GC_INTERVAL_MS = 30_000; // 30 seconds
    private static volatile boolean running = false;

    public static void init(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            XposedHelpers.findAndHookMethod(
                "android.app.Application",
                lpparam.classLoader,
                "onCreate",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        if (running) return;
                        running = true;
                        startPreemptiveGC();
                    }
                }
            );
        } catch (Throwable t) {
            XposedBridge.log("[TikTokFixer] GCHook failed: " + t.getMessage());
        }
    }

    private static void startPreemptiveGC() {
        Thread gcThread = new Thread(() -> {
            while (running) {
                try {
                    Thread.sleep(GC_INTERVAL_MS);

                    Runtime rt = Runtime.getRuntime();
                    long freeMem  = rt.freeMemory();
                    long totalMem = rt.totalMemory();
                    long maxMem   = rt.maxMemory();
                    long usedMem  = totalMem - freeMem;
                    long usedPct  = (usedMem * 100) / maxMem;

                    if (usedPct >= 75) {
                        XposedBridge.log("[TikTokFixer] Pre-emptive GC @ " + usedPct + "% heap");
                        rt.gc();
                        rt.runFinalization();
                        rt.gc();
                    }

                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    running = false;
                } catch (Throwable t) {
                    XposedBridge.log("[TikTokFixer] GC thread error: " + t.getMessage());
                }
            }
        }, "TikTokFixer-GC");

        gcThread.setDaemon(true);
        gcThread.setPriority(Thread.MIN_PRIORITY);
        gcThread.start();
        XposedBridge.log("[TikTokFixer] Pre-emptive GC thread started");
    }
}
