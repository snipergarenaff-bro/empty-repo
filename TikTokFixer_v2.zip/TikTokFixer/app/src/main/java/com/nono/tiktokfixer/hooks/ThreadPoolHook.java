package com.nono.tiktokfixer.hooks;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class ThreadPoolHook {

    private static final int CORE_POOL   = 4;
    private static final int MAX_POOL    = 12;
    private static final int QUEUE_SIZE  = 128;
    private static final long KEEP_ALIVE = 30L;

    public static void init(XC_LoadPackage.LoadPackageParam lpparam) {

        // Hook ThreadPoolExecutor constructor — cap unlimited pools
        try {
            XposedHelpers.findAndHookConstructor(
                ThreadPoolExecutor.class,
                int.class, int.class, long.class,
                TimeUnit.class,
                java.util.concurrent.BlockingQueue.class,
                new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        int maxPool = (int) param.args[1];
                        if (maxPool > 64 || maxPool == Integer.MAX_VALUE) {
                            XposedBridge.log("[TikTokFixer] ThreadPool capped: "
                                + maxPool + " -> " + MAX_POOL);
                            param.args[0] = CORE_POOL;
                            param.args[1] = MAX_POOL;
                            param.args[2] = KEEP_ALIVE;
                            param.args[3] = TimeUnit.SECONDS;
                            param.args[4] = new LinkedBlockingQueue<>(QUEUE_SIZE);
                        }
                    }
                }
            );
        } catch (Throwable t) {
            XposedBridge.log("[TikTokFixer] ThreadPoolHook constructor failed: " + t.getMessage());
        }

        // Replace AsyncTask.THREAD_POOL_EXECUTOR with bounded pool
        try {
            ThreadPoolExecutor boundedPool = new ThreadPoolExecutor(
                CORE_POOL, MAX_POOL,
                KEEP_ALIVE, TimeUnit.SECONDS,
                new LinkedBlockingQueue<>(QUEUE_SIZE)
            );
            boundedPool.allowCoreThreadTimeOut(true);

            Class<?> asyncTaskClass = XposedHelpers.findClass(
                "android.os.AsyncTask", lpparam.classLoader
            );
            XposedHelpers.setStaticObjectField(
                asyncTaskClass, "THREAD_POOL_EXECUTOR", boundedPool
            );
            XposedBridge.log("[TikTokFixer] AsyncTask.THREAD_POOL_EXECUTOR replaced OK");

        } catch (Throwable t) {
            XposedBridge.log("[TikTokFixer] AsyncTask replace failed: " + t.getMessage());
        }
    }
}
