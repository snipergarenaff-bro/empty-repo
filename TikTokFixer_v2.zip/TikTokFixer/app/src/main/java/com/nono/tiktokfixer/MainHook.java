package com.nono.tiktokfixer;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import com.nono.tiktokfixer.hooks.ThreadPoolHook;
import com.nono.tiktokfixer.hooks.MemoryHook;
import com.nono.tiktokfixer.hooks.GCHook;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TARGET_PKG = "com.zhiliaoapp.musically";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!lpparam.packageName.equals(TARGET_PKG)) return;

        ThreadPoolHook.init(lpparam);
        MemoryHook.init(lpparam);
        GCHook.init(lpparam);
    }
}
