package com.nono.tiktokfixer.hooks;

import android.app.Activity;
import android.app.Application;
import android.content.ComponentCallbacks2;
import android.content.res.Configuration;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MemoryHook {

    public static void init(XC_LoadPackage.LoadPackageParam lpparam) {

        // Register memory trim callback on app start
        try {
            XposedHelpers.findAndHookMethod(
                Application.class,
                "onCreate",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        Application app = (Application) param.thisObject;
                        app.registerComponentCallbacks(new ComponentCallbacks2() {
                            @Override
                            public void onTrimMemory(int level) {
                                XposedBridge.log("[TikTokFixer] onTrimMemory level: " + level);
                                if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
                                    Runtime.getRuntime().gc();
                                    Runtime.getRuntime().runFinalization();
                                    Runtime.getRuntime().gc();
                                    XposedBridge.log("[TikTokFixer] GC triggered on memory pressure");
                                }
                            }

                            @Override
                            public void onLowMemory() {
                                Runtime.getRuntime().gc();
                                XposedBridge.log("[TikTokFixer] onLowMemory GC triggered");
                            }

                            @Override
                            public void onConfigurationChanged(Configuration cfg) {}
                        });
                    }
                }
            );
        } catch (Throwable t) {
            XposedBridge.log("[TikTokFixer] MemoryHook Application failed: " + t.getMessage());
        }

        // GC on Activity stop to release held references
        try {
            XposedHelpers.findAndHookMethod(
                Activity.class, "onStop",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        Runtime.getRuntime().gc();
                    }
                }
            );
        } catch (Throwable t) {
            XposedBridge.log("[TikTokFixer] MemoryHook Activity onStop failed: " + t.getMessage());
        }
    }
}
