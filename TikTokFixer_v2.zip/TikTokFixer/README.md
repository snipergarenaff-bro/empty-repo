# TikTok Fixer — LSPosed Module

Fixes TikTok (com.zhiliaoapp.musically) memory leaks, GC blocking, touch freeze and sound off issues.

## What it fixes
| Issue | Hook |
|---|---|
| ThreadPoolExecutor overflow (50+ times on launch) | ThreadPoolHook |
| GC blocked for 6.28s | GCHook |
| OOM — 0 free bytes | MemoryHook |
| Heap wraparound 18446744073705677256 | MemoryHook + GCHook |
| Touch freeze + sound off | All combined |

## Build
1. Open in Android Studio
2. `./gradlew assembleDebug`
3. APK at `app/build/outputs/apk/debug/app-debug.apk`

## Install
```
adb install app-debug.apk
```
Then enable in LSPosed Manager → Modules → TikTok Fixer → Scope: com.zhiliaoapp.musically → Reboot
